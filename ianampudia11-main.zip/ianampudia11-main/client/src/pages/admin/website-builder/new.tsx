import React from 'react';
import WebsiteBuilderEditor from './editor';

export default function NewWebsite() {
  return <WebsiteBuilderEditor />;
}
