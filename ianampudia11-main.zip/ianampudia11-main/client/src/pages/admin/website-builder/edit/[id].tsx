import React from 'react';
import WebsiteBuilderEditor from '../editor';

export default function EditWebsite() {
  return <WebsiteBuilderEditor />;
}
